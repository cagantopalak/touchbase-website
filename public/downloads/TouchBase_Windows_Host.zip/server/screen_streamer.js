const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

class ScreenStreamer {
    constructor() {
        this.subscribers = new Set();
        this.process = null;
        this.captureInterval = null;
        this.isCapturing = false;
        this.lastFrameTime = 0;
        this.exePath = path.join(__dirname, '..', 'server_native', 'publish', 'ScreenCapture.exe');
        this.hasExe = fs.existsSync(this.exePath);
    }

    startProcess() {
        if (!this.hasExe || this.process) return;

        try {
            this.process = spawn(this.exePath, [], {
                stdio: ['pipe', 'pipe', 'ignore']
            });

            let buffer = '';
            this.process.stdout.on('data', (data) => {
                buffer += data.toString();
                const lines = buffer.split('\n');
                buffer = lines.pop(); // keep last incomplete chunk

                for (const line of lines) {
                    const trimmed = line.trim();
                    if (trimmed.startsWith('FRAME:')) {
                        const base64 = trimmed.substring(6);
                        this.broadcastFrame('data:image/jpeg;base64,' + base64);
                        this.isCapturing = false;
                    } else if (trimmed.startsWith('ERROR:')) {
                        // Desktop might be locked or GDI denied
                        this.isCapturing = false;
                    }
                }
            });

            this.process.on('error', (err) => {
                console.error('[ScreenStreamer] Process error:', err.message);
                this.process = null;
            });

            this.process.on('exit', () => {
                this.process = null;
            });
        } catch (e) {
            console.error('[ScreenStreamer] Failed to spawn:', e);
            this.process = null;
        }
    }

    stopProcess() {
        if (this.process) {
            try {
                this.process.stdin.write('exit\n');
                this.process.kill();
            } catch (e) {}
            this.process = null;
        }
    }

    addSubscriber(ws) {
        this.subscribers.add(ws);
        if (this.subscribers.size === 1) {
            this.startStreaming();
        }
    }

    removeSubscriber(ws) {
        this.subscribers.delete(ws);
        if (this.subscribers.size === 0) {
            this.stopStreaming();
        }
    }

    startStreaming() {
        this.startProcess();
        if (this.captureInterval) clearInterval(this.captureInterval);

        // ~6.6 FPS (every 150ms)
        this.captureInterval = setInterval(() => {
            if (this.subscribers.size === 0) {
                this.stopStreaming();
                return;
            }

            if (this.process && this.process.stdin.writable && !this.isCapturing) {
                this.isCapturing = true;
                this.process.stdin.write('capture\n');
            }
        }, 150);
    }

    stopStreaming() {
        if (this.captureInterval) {
            clearInterval(this.captureInterval);
            this.captureInterval = null;
        }
        this.stopProcess();
    }

    broadcastFrame(frameData) {
        const payload = JSON.stringify({ type: 'screen_frame', frame: frameData });
        for (const client of this.subscribers) {
            if (client.readyState === 1 /* OPEN */) {
                client.send(payload);
            }
        }
    }
}

module.exports = new ScreenStreamer();
