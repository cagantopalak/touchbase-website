const { spawn } = require('child_process');
const path = require('path');

class InputBridge {
    constructor() {
        const exePath = path.join(__dirname, '..', 'server_native', 'publish', 'WindowsInputHelper.exe');
        this.process = spawn(exePath, [], {
            stdio: ['pipe', 'ignore', 'ignore']
        });

        this.process.on('error', (err) => {
            console.error('Failed to start native input helper:', err);
        });

        this.process.on('exit', (code) => {
            console.log('Native input helper exited with code:', code);
        });
    }

    send(command) {
        if (this.process && this.process.stdin.writable) {
            this.process.stdin.write(command + '\n');
        }
    }

    move(dx, dy) {
        this.send(`move ${Math.round(dx)} ${Math.round(dy)}`);
    }

    click(button = 'left') {
        this.send(`click ${button}`);
    }

    mouseDown(button = 'left') {
        this.send(`mousedown ${button}`);
    }

    mouseUp(button = 'left') {
        this.send(`mouseup ${button}`);
    }

    scroll(dy) {
        this.send(`scroll ${Math.round(dy)}`);
    }

    key(keyName, action = 'press') {
        this.send(`key ${keyName} ${action}`);
    }

    typeText(text) {
        if (!text) return;
        this.send(`type ${text}`);
    }

    unlock(pin) {
        if (!pin) return;
        this.send(`unlock ${pin}`);
    }

    macro(name) {
        if (!name) return;
        this.send(`macro ${name}`);
    }

    shortcut(name) {
        switch (name) {
            case 'alt_tab':
                this.send('key ALT down');
                this.send('key TAB press');
                this.send('key ALT up');
                break;
            case 'close_tab':
                this.send('key CTRL down');
                this.send('key w press');
                this.send('key CTRL up');
                break;
            case 'close_window':
                this.send('key ALT down');
                this.send('key F4 press');
                this.send('key ALT up');
                break;
            case 'fullscreen':
                this.send('key F11 press');
                break;
            case 'esc':
                this.send('key ESC press');
                break;
            case 'win':
                this.send('key WIN press');
                break;
            case 'seek_forward':
                this.send('key RIGHT press');
                break;
            case 'seek_backward':
                this.send('key LEFT press');
                break;
            case 'play_pause':
                this.send('key MEDIA_PLAY_PAUSE press');
                break;
            case 'next':
                this.send('key MEDIA_NEXT press');
                break;
            case 'prev':
                this.send('key MEDIA_PREV press');
                break;
            case 'vol_up':
                this.send('key VOLUME_UP press');
                break;
            case 'vol_down':
                this.send('key VOLUME_DOWN press');
                break;
            case 'vol_mute':
                this.send('key VOLUME_MUTE press');
                break;
        }
    }

    destroy() {
        if (this.process) {
            this.send('exit');
            this.process.kill();
        }
    }
}

module.exports = new InputBridge();
