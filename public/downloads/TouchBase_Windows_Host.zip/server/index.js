const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const qrcode = require('qrcode');
const dgram = require('dgram');
const input = require('./input_bridge');
const screenStreamer = require('./screen_streamer');

const PORT = 38472;
const CONFIG_FILE = path.join(__dirname, 'config.json');

// Config management
let config = {
    pairingSecret: crypto.randomBytes(8).toString('hex').toUpperCase(),
    pairedTokens: [],
    deviceName: os.hostname()
};

if (fs.existsSync(CONFIG_FILE)) {
    try {
        const saved = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
        config = { ...config, ...saved };
    } catch (e) {
        console.error('Error reading config file, using default:', e);
    }
} else {
    saveConfig();
}

function saveConfig() {
    try {
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
    } catch (e) {
        console.error('Error saving config:', e);
    }
}

// Get local IP addresses
function getLocalIPs() {
    const interfaces = os.networkInterfaces();
    const ips = [];
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal) {
                ips.push(iface.address);
            }
        }
    }
    return ips;
}

// Get active primary MAC address for WoL
function getActiveMac() {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal && iface.mac && iface.mac !== '00:00:00:00:00:00') {
                return iface.mac.toUpperCase();
            }
        }
    }
    return null;
}

// Send Wake-on-LAN UDP Magic Packet to port 9
function sendWakeOnLan(targetMac) {
    return new Promise((resolve, reject) => {
        try {
            const cleanMac = (targetMac || getActiveMac() || '').replace(/[^0-9A-Fa-f]/g, '');
            if (cleanMac.length !== 12) {
                return reject(new Error('Invalid MAC address length'));
            }
            const macBuf = Buffer.from(cleanMac, 'hex');
            const magic = Buffer.concat([
                Buffer.alloc(6, 0xff),
                Buffer.concat(Array(16).fill(macBuf))
            ]);
            const socket = dgram.createSocket('udp4');
            socket.bind(() => {
                socket.setBroadcast(true);
                socket.send(magic, 9, '255.255.255.255', (err) => {
                    socket.close();
                    if (err) reject(err);
                    else resolve(true);
                });
            });
        } catch (err) {
            reject(err);
        }
    });
}

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// API: Discover & Info (includes active MAC for zero-friction WoL)
app.get('/api/info', (req, res) => {
    res.json({
        deviceName: config.deviceName,
        requiresPairing: config.pairedTokens.length === 0,
        pairedCount: config.pairedTokens.length,
        mac: getActiveMac(),
        ips: getLocalIPs()
    });
});

// API: Trigger Wake-on-LAN broadcast
app.post('/api/wol', async (req, res) => {
    const { mac } = req.body;
    try {
        await sendWakeOnLan(mac);
        res.json({ success: true, message: 'Magic Packet broadcasted' });
    } catch (e) {
        res.status(400).json({ success: false, error: e.message });
    }
});

// API: Auto-Token for owner (seamless zero friction)
app.get('/api/auto-token', (req, res) => {
    if (config.pairedTokens.length > 0) {
        return res.json({ token: config.pairedTokens[0].token, deviceName: config.deviceName });
    }
    const token = crypto.randomBytes(32).toString('hex');
    config.pairedTokens.push({
        token,
        clientName: 'Android Phone',
        pairedAt: new Date().toISOString()
    });
    saveConfig();
    return res.json({ token, deviceName: config.deviceName });
});

// API: Pair device (One-Time)
app.post('/api/pair', (req, res) => {
    const { code, clientName } = req.body;
    
    // If user provides the pairing code (or if first pairing is open with secret)
    if (code && code.trim().toUpperCase() === config.pairingSecret.toUpperCase()) {
        const token = crypto.randomBytes(32).toString('hex');
        const newDevice = {
            token,
            clientName: clientName || 'Android Phone',
            pairedAt: new Date().toISOString()
        };
        config.pairedTokens.push(newDevice);
        saveConfig();
        console.log('[AUTH] Successfully paired with device:', newDevice.clientName);
        return res.json({ success: true, token, deviceName: config.deviceName });
    }

    return res.status(401).json({ success: false, error: 'Geçersiz eşleştirme kodu!' });
});

// API: Verify token
app.post('/api/verify', (req, res) => {
    const { token } = req.body;
    const isPaired = config.pairedTokens.some(d => d.token === token);
    if (isPaired) {
        return res.json({ success: true, deviceName: config.deviceName });
    }
    return res.status(401).json({ success: false, error: 'Yetkisiz cihaz' });
});

// Create HTTP and WebSocket Server
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

wss.on('connection', (ws, req) => {
    let isAuthenticated = false;
    let clientInfo = null;

    ws.on('message', (message) => {
        try {
            const data = JSON.parse(message);

            if (data.type === 'ping') {
                ws.send(JSON.stringify({ type: 'pong', deviceName: config.deviceName }));
                return;
            }

            // 2. Control Commands
            switch (data.type) {
                case 'move':
                    input.move(data.dx, data.dy);
                    break;
                case 'click':
                    input.click(data.button || 'left');
                    break;
                case 'mousedown':
                    input.mouseDown(data.button || 'left');
                    break;
                case 'mouseup':
                    input.mouseUp(data.button || 'left');
                    break;
                case 'scroll':
                    input.scroll(data.dy);
                    break;
                case 'key':
                    input.key(data.key, data.action || 'press');
                    break;
                case 'type':
                    input.typeText(data.text);
                    break;
                case 'shortcut':
                    input.shortcut(data.name);
                    break;
                case 'launch':
                    if (data.app === 'youtube') {
                        require('child_process').exec('start https://youtube.com');
                    } else if (data.app === 'netflix') {
                        require('child_process').exec('start https://netflix.com');
                    } else if (data.app === 'spotify') {
                        require('child_process').exec('start spotify: || start https://open.spotify.com');
                    } else if (data.app === 'browser') {
                        require('child_process').exec('start https://google.com');
                    }
                    break;
                case 'power':
                    if (data.action === 'sleep') {
                        require('child_process').exec('rundll32.exe powrprof.dll,SetSuspendState 0,1,0');
                    } else if (data.action === 'lock') {
                        require('child_process').exec('rundll32.exe user32.dll,LockWorkStation');
                    }
                    break;
                case 'unlock':
                    if (data.pin) {
                        input.unlock(data.pin);
                    }
                    break;
                case 'macro':
                    if (data.name) {
                        input.macro(data.name);
                    }
                    break;
                case 'wol':
                    sendWakeOnLan(data.mac).catch((err) => {
                        console.error('[WoL Error]', err.message);
                    });
                    break;
                case 'screen_stream_start':
                    screenStreamer.addSubscriber(ws);
                    break;
                case 'screen_stream_stop':
                    screenStreamer.removeSubscriber(ws);
                    break;
                case 'ping':
                    ws.send(JSON.stringify({ type: 'pong', deviceName: config.deviceName }));
                    break;
            }
        } catch (err) {
            console.error('[WS Error]', err);
        }
    });

    ws.on('close', () => {
        screenStreamer.removeSubscriber(ws);
        if (clientInfo) {
            console.log('[WS] Client disconnected:', clientInfo.clientName);
        }
    });
});

// Start Server
server.listen(PORT, '0.0.0.0', async () => {
    const localIPs = getLocalIPs();
    const primaryIP = localIPs[0] || 'localhost';
    const pairUrl = `http://${primaryIP}:${PORT}/?pair=${config.pairingSecret}`;

    console.log('====================================================');
    console.log('       🚀 REMOTE CONTROLLER WINDOWS SUNUCUSU        ');
    console.log('====================================================');
    console.log(`PC Adı           : ${config.deviceName}`);
    console.log(`Port             : ${PORT}`);
    console.log(`Eşleştirme Kodu  : ${config.pairingSecret}`);
    console.log(`Eşleşmiş Cihazlar: ${config.pairedTokens.length} adet`);
    console.log('----------------------------------------------------');
    console.log('İlk eşleştirme için telefonunuzdan şu adrese gidin:');
    console.log(`👉 ${pairUrl}`);
    console.log('----------------------------------------------------');
    
    try {
        console.log('\n📱 Telefonunuzun kamerasıyla bu QR kodu okutabilirsiniz:');
        const qrString = await qrcode.toString(pairUrl, { type: 'terminal', small: true });
        console.log(qrString);
    } catch (e) {
        // ignore terminal qr error
    }

    console.log('====================================================');
    console.log('💡 Telefonunuz 1 kez bağlandıktan sonra bir daha asla');
    console.log('   QR kod veya IP sormayacaktır. Otomatik bağlanır.');
    console.log('====================================================\n');
});

// APK Builder helper
if (process.env.BUILD_APK === '1') {
    const { execSync } = require('child_process');
    const root = path.resolve(__dirname, '..');
    const jdk = path.join(root, 'jdk17', 'jdk-17.0.10+7');
    const sdk = path.join(root, 'android-sdk');
    const buildTools = path.join(sdk, 'build-tools', '33.0.2');
    const platform = path.join(sdk, 'platforms', 'android-33', 'android.jar');

    const appDir = path.join(root, 'android_app');
    const srcDir = path.join(appDir, 'src', 'com', 'touchbase', 'remote');
    const resDir = path.join(appDir, 'res');
    const buildDir = path.join(appDir, 'build');
    const compiledRes = path.join(buildDir, 'compiled_res');
    const objDir = path.join(buildDir, 'obj');
    const genDir = path.join(buildDir, 'gen');

    fs.rmSync(buildDir, { recursive: true, force: true });
    fs.mkdirSync(srcDir, { recursive: true });
    fs.mkdirSync(path.join(resDir, 'values'), { recursive: true });
    fs.mkdirSync(path.join(resDir, 'mipmap-hdpi'), { recursive: true });
    fs.mkdirSync(path.join(resDir, 'mipmap-xhdpi'), { recursive: true });
    fs.mkdirSync(path.join(resDir, 'mipmap-xxhdpi'), { recursive: true });
    fs.mkdirSync(path.join(resDir, 'mipmap-xxxhdpi'), { recursive: true });
    fs.mkdirSync(compiledRes, { recursive: true });
    fs.mkdirSync(objDir, { recursive: true });
    fs.mkdirSync(genDir, { recursive: true });

    const icon = path.join(root, 'public', 'icon.png');
    fs.copyFileSync(icon, path.join(resDir, 'mipmap-hdpi', 'ic_launcher.png'));
    fs.copyFileSync(icon, path.join(resDir, 'mipmap-xhdpi', 'ic_launcher.png'));
    fs.copyFileSync(icon, path.join(resDir, 'mipmap-xxhdpi', 'ic_launcher.png'));
    fs.copyFileSync(icon, path.join(resDir, 'mipmap-xxxhdpi', 'ic_launcher.png'));

    fs.writeFileSync(path.join(resDir, 'values', 'strings.xml'), '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="app_name">TouchBase</string>\n</resources>');
    fs.writeFileSync(path.join(resDir, 'values', 'styles.xml'), '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <style name="AppTheme" parent="android:Theme.Material.NoActionBar.Fullscreen">\n        <item name="android:windowBackground">#000000</item>\n        <item name="android:colorBackground">#000000</item>\n        <item name="android:statusBarColor">#000000</item>\n        <item name="android:navigationBarColor">#000000</item>\n        <item name="android:windowFullscreen">true</item>\n    </style>\n</resources>');

    const manifest = '<?xml version="1.0" encoding="utf-8"?>\n' +
    '<manifest xmlns:android="http://schemas.android.com/apk/res/android"\n' +
    '    package="com.touchbase.remote"\n' +
    '    android:versionCode="1"\n' +
    '    android:versionName="1.0">\n' +
    '    <uses-sdk android:minSdkVersion="23" android:targetSdkVersion="33" />\n' +
    '    <uses-permission android:name="android.permission.INTERNET" />\n' +
    '    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />\n' +
    '    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />\n' +
    '    <uses-permission android:name="android.permission.CHANGE_WIFI_MULTICAST_STATE" />\n' +
    '    <uses-permission android:name="android.permission.VIBRATE" />\n' +
    '    <uses-permission android:name="android.permission.USE_BIOMETRIC" />\n' +
    '    <uses-permission android:name="android.permission.USE_FINGERPRINT" />\n' +
    '    <uses-permission android:name="com.android.vending.BILLING" />\n' +
    '    <application\n' +
    '        android:label="@string/app_name"\n' +
    '        android:icon="@mipmap/ic_launcher"\n' +
    '        android:roundIcon="@mipmap/ic_launcher"\n' +
    '        android:theme="@style/AppTheme"\n' +
    '        android:hardwareAccelerated="true"\n' +
    '        android:usesCleartextTraffic="true">\n' +
    '        <activity\n' +
    '            android:name=".MainActivity"\n' +
    '            android:exported="true"\n' +
    '            android:theme="@style/AppTheme"\n' +
    '            android:configChanges="orientation|screenSize|screenLayout|keyboard|keyboardHidden"\n' +
    '            android:windowSoftInputMode="adjustResize">\n' +
    '            <intent-filter>\n' +
    '                <action android:name="android.intent.action.MAIN" />\n' +
    '                <category android:name="android.intent.category.LAUNCHER" />\n' +
    '            </intent-filter>\n' +
    '        </activity>\n' +
    '    </application>\n' +
    '</manifest>';
    fs.writeFileSync(path.join(appDir, 'AndroidManifest.xml'), manifest);

    const mainActivity = `package com.touchbase.remote;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;
import android.view.Gravity;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String PREF_NAME = "TouchBasePrefs";
    private static final String KEY_SERVER = "server_url";
    private static final String DEFAULT_URL = "http://192.168.0.139:38472";

    public class AndroidInterface {
        @JavascriptInterface
        public void toggleOrientation() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    int current = getRequestedOrientation();
                    if (current == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE || 
                        current == ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE) {
                        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                    } else if (current == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT ||
                               current == ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT) {
                        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                    } else {
                        int width = getResources().getDisplayMetrics().widthPixels;
                        int height = getResources().getDisplayMetrics().heightPixels;
                        if (width > height) {
                            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                        } else {
                            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                        }
                    }
                    hideSystemUI();
                }
            });
        }

        @JavascriptInterface
        public void setLandscape() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                    hideSystemUI();
                }
            });
        }

        @JavascriptInterface
        public void setPortrait() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                    hideSystemUI();
                }
            });
        }

        @JavascriptInterface
        public void setAuto() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
                    hideSystemUI();
                }
            });
        }

        @JavascriptInterface
        public boolean sendWakeOnLan(String macStr) {
            if (macStr == null) return false;
            try {
                String clean = macStr.replaceAll("[^0-9A-Fa-f]", "");
                if (clean.length() != 12) return false;
                byte[] macBytes = new byte[6];
                for (int i = 0; i < 6; i++) {
                    macBytes[i] = (byte) Integer.parseInt(clean.substring(i * 2, i * 2 + 2), 16);
                }
                byte[] bytes = new byte[102];
                for (int i = 0; i < 6; i++) {
                    bytes[i] = (byte) 0xff;
                }
                for (int i = 6; i < bytes.length; i += 6) {
                    System.arraycopy(macBytes, 0, bytes, i, 6);
                }
                InetAddress address = InetAddress.getByName("255.255.255.255");
                DatagramPacket packet = new DatagramPacket(bytes, bytes.length, address, 9);
                DatagramSocket socket = new DatagramSocket();
                socket.setBroadcast(true);
                socket.send(packet);
                socket.close();
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        @JavascriptInterface
        public boolean isProUnlocked() {
            SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
            return prefs.getBoolean("is_pro_unlocked", false);
        }

        @JavascriptInterface
        public void setProUnlocked(final boolean unlocked) {
            SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
            prefs.edit().putBoolean("is_pro_unlocked", unlocked).apply();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    webView.evaluateJavascript("window.onProStatusChanged && window.onProStatusChanged(" + unlocked + ");", null);
                }
            });
        }

        @JavascriptInterface
        public void launchBillingFlow(final String productId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    setProUnlocked(true);
                    webView.evaluateJavascript("window.onBillingSuccess && window.onBillingSuccess('" + productId + "');", null);
                }
            });
        }

        @JavascriptInterface
        public void restorePurchases() {
            final boolean unlocked = isProUnlocked();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    webView.evaluateJavascript("window.onRestorePurchasesResult && window.onRestorePurchasesResult(" + unlocked + ");", null);
                }
            });
        }

        @JavascriptInterface
        public void saveMac(String mac) {
            SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
            prefs.edit().putString("pc_mac_address", mac).apply();
        }

        @JavascriptInterface
        public String getSavedMac() {
            SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
            return prefs.getString("pc_mac_address", "");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.BLACK);
            getWindow().setNavigationBarColor(Color.BLACK);
        }

        hideSystemUI();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.addJavascriptInterface(new AndroidInterface(), "AndroidBridge");
        
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setUseWideViewPort(true);
        ws.setLoadWithOverviewMode(true);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            ws.setMediaPlaybackRequiresUserGesture(false);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                showConfigDialog();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());

        setContentView(webView);

        SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        String url = prefs.getString(KEY_SERVER, DEFAULT_URL);
        webView.loadUrl(url);
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void showConfigDialog() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                LinearLayout layout = new LinearLayout(MainActivity.this);
                layout.setOrientation(LinearLayout.VERTICAL);
                layout.setBackgroundColor(Color.BLACK);
                layout.setPadding(60, 100, 60, 60);
                layout.setGravity(Gravity.CENTER_HORIZONTAL);

                TextView title = new TextView(MainActivity.this);
                title.setText("TouchBase Connection");
                title.setTextColor(Color.WHITE);
                title.setTextSize(22);
                title.setPadding(0, 0, 0, 40);
                layout.addView(title);

                final EditText input = new EditText(MainActivity.this);
                final SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
                input.setText(prefs.getString(KEY_SERVER, DEFAULT_URL));
                input.setTextColor(Color.WHITE);
                input.setHintTextColor(Color.GRAY);
                input.setBackgroundColor(Color.parseColor("#151515"));
                input.setPadding(30, 30, 30, 30);
                layout.addView(input);

                Button btn = new Button(MainActivity.this);
                btn.setText("Connect");
                btn.setBackgroundColor(Color.parseColor("#252525"));
                btn.setTextColor(Color.WHITE);
                btn.setPadding(30, 30, 30, 30);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 40, 0, 0);
                btn.setLayoutParams(lp);

                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String newUrl = input.getText().toString().trim();
                        if (!newUrl.startsWith("http://") && !newUrl.startsWith("https://")) {
                            newUrl = "http://" + newUrl;
                        }
                        prefs.edit().putString(KEY_SERVER, newUrl).apply();
                        setContentView(webView);
                        webView.loadUrl(newUrl);
                    }
                });
                layout.addView(btn);

                setContentView(layout);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
`;
    fs.writeFileSync(path.join(srcDir, 'MainActivity.java'), mainActivity);

    console.log('Compiling resources with aapt2...');
    execSync(`"${path.join(buildTools, 'aapt2.exe')}" compile --dir "${resDir}" -o "${path.join(compiledRes, 'resources.zip')}"`, { stdio: 'inherit' });

    console.log('Linking APK with aapt2...');
    execSync(`"${path.join(buildTools, 'aapt2.exe')}" link -I "${platform}" --manifest "${path.join(appDir, 'AndroidManifest.xml')}" "${path.join(compiledRes, 'resources.zip')}" -o "${path.join(buildDir, 'app_unaligned.apk')}" --java "${genDir}" --auto-add-overlay`, { stdio: 'inherit' });

    console.log('Compiling Java sources...');
    const javac = path.join(jdk, 'bin', 'javac.exe');
    function getJavaFiles(dir) {
        let results = [];
        const list = fs.readdirSync(dir);
        list.forEach(file => {
            const fullPath = path.join(dir, file);
            const stat = fs.statSync(fullPath);
            if (stat && stat.isDirectory()) results = results.concat(getJavaFiles(fullPath));
            else if (file.endsWith('.java')) results.push(`"${fullPath}"`);
        });
        return results;
    }
    const javaFiles = getJavaFiles(srcDir).concat(getJavaFiles(genDir));
    execSync(`"${javac}" -cp "${platform}" -d "${objDir}" ${javaFiles.join(' ')}`, { stdio: 'inherit' });

    console.log('Converting classes to DEX with d8.jar...');
    const d8Jar = path.join(buildTools, 'lib', 'd8.jar');
    function getClassFiles(dir) {
        let results = [];
        const list = fs.readdirSync(dir);
        list.forEach(file => {
            const fullPath = path.join(dir, file);
            const stat = fs.statSync(fullPath);
            if (stat && stat.isDirectory()) results = results.concat(getClassFiles(fullPath));
            else if (file.endsWith('.class')) results.push(`"${fullPath}"`);
        });
        return results;
    }
    const classFiles = getClassFiles(objDir);
    const javaBin = path.join(jdk, 'bin', 'java.exe');
    execSync(`"${javaBin}" -cp "${d8Jar}" com.android.tools.r8.D8 --output "${buildDir}" ${classFiles.join(' ')}`, { stdio: 'inherit' });

    console.log('Adding classes.dex to APK...');
    const jar = path.join(jdk, 'bin', 'jar.exe');
    execSync(`"${jar}" -uf "${path.join(buildDir, 'app_unaligned.apk')}" -C "${buildDir}" classes.dex`, { stdio: 'inherit' });

    console.log('Aligning APK with zipalign...');
    const zipalign = path.join(buildTools, 'zipalign.exe');
    execSync(`"${zipalign}" -f -p 4 "${path.join(buildDir, 'app_unaligned.apk')}" "${path.join(buildDir, 'app_aligned.apk')}"`, { stdio: 'inherit' });

    console.log('Signing APK with apksigner.jar...');
    const keystore = path.join(appDir, 'debug.keystore');
    const keytool = path.join(jdk, 'bin', 'keytool.exe');
    if (!fs.existsSync(keystore)) {
        execSync(`"${keytool}" -genkeypair -validity 10000 -dname "CN=TouchBase,O=TouchBase,C=US" -keystore "${keystore}" -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048`, { stdio: 'inherit' });
    }
    const apksignerJar = path.join(buildTools, 'lib', 'apksigner.jar');
    const targetApk = path.join(root, 'public', 'TouchBase.apk');
    execSync(`"${javaBin}" -jar "${apksignerJar}" sign --ks "${keystore}" --ks-pass pass:android --ks-key-alias androiddebugkey --key-pass pass:android --out "${targetApk}" "${path.join(buildDir, 'app_aligned.apk')}"`, { stdio: 'inherit' });

    console.log('🎉 APK BUILD COMPLETED SUCCESSFULLY!');
    console.log('File located at:', targetApk);
    process.exit(0);
}

