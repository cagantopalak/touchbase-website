@echo off
title Remote Controller Server
echo ===================================================
echo     Starting Remote Controller Server...
echo ===================================================
cd /d "%~dp0"

:: Eski veya askida kalan 38472 portundaki sureci sonlandir
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":38472" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)

node server/index.js
pause
