@echo off
echo ===================================================
echo   TouchBase Windows Baslangicina Ekleniyor...
echo ===================================================

powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut([System.IO.Path]::Combine($env:APPDATA, 'Microsoft\Windows\Start Menu\Programs\Startup\TouchBase.lnk')); $s.TargetPath = [System.IO.Path]::Combine('%~dp0', 'publish_tray\tray_app.exe'); $s.WorkingDirectory = [System.IO.Path]::Combine('%~dp0', 'publish_tray'); $s.IconLocation = [System.IO.Path]::Combine('%~dp0', 'public\icon.ico'); $s.Save()"

echo.
echo [BASARILI] TouchBase basariyla Windows Baslangicina eklendi!
echo Bilgisayariniz her acildiginda hicbir CMD penceresi cikmadan
echo sistem tepsisinde (saatin yaninda) sessizce calisacaktir.
echo.
pause
